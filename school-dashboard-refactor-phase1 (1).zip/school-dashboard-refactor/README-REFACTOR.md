# School Dashboard refactor, phase 1

This package safely extracts the new Support Sessions feature from the 13,000+ line `Dashboard.tsx`.

## Added

- `src/components/support/SupportSessions.tsx`
- `src/services/supportSessionsService.ts`
- `src/types/supportSession.ts`
- `src/utils/studentStatus.ts`
- updated `src/components/Dashboard.tsx`

## Improvements

- Support-session UI, state, and Supabase operations no longer live inside `Dashboard.tsx`.
- Duplicate active sessions for the same student are blocked.
- Starting a session rolls back the inserted session if updating the student fails.
- Loading and saving errors are visible in the UI.
- Student status rules are centralized.
- Returning to class clears `withStaff` without marking the student late.

## Install into your repository

Copy the included `src` folder over your repository's `src` folder, preserving your other files.

Then run:

```bash
npm run build
npm run dev
```

Commit only after testing:

```bash
git add src/components/Dashboard.tsx \
  src/components/support/SupportSessions.tsx \
  src/services/supportSessionsService.ts \
  src/types/supportSession.ts \
  src/utils/studentStatus.ts
git commit -m "Extract support sessions into components and services"
git push origin main
```

## Recommended next phases

1. Extract `TeachingMode.tsx` and centralize all classroom status transitions.
2. Extract `AttendancePage.tsx` and reuse the same status actions.
3. Move student loading and notes into hooks/services.
4. Add proper shared `Student` types and then enable stricter TypeScript checks.
